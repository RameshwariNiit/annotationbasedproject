package com.MyShopingB.dao;

import java.util.List;

import com.MyShopingB.model.User;
public interface UserDao 
{
	public void saveorupdate(User user);
	public List<User> viewcustomerd();
}
