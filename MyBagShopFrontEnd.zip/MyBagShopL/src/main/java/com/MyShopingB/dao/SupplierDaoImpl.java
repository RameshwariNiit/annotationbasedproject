package com.MyShopingB.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.MyShopingB.model.Supplier;
import com.MyShopingB.model.User;

@Repository("supplierdaoimpl")
public class SupplierDaoImpl implements SupplierDao 
{

	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveorupdate(Supplier supplier) 
	{
		System.out.println("i am in supplier dao class");
		Session s = sessionFactory.openSession();
		System.out.println("sesssion="+s);
		s.saveOrUpdate(supplier);
		System.out.println("supplier data successfully done"+s);
	
		
	}

		
	@SuppressWarnings("unchecked")
	public List<Supplier> viewsupplierd() {
		System.out.println("I am in View Supplier Dao Function");
		Session s = sessionFactory.openSession();
		Transaction tx  = s.beginTransaction();
		List<Supplier> slist = s.createCriteria(Supplier.class).list();
		return slist;
	}
	

}
