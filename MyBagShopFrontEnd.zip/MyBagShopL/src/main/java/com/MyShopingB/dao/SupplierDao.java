package com.MyShopingB.dao;

import java.util.List;

import com.MyShopingB.model.Supplier;


public interface SupplierDao
{
	public void saveorupdate(Supplier supplier);
	public List<Supplier> viewsupplierd();
}
