package com.MyShopingB.dao;

import java.util.List;

import com.MyShopingB.model.Product;

public interface ProductDao
{

	public void saveorupdate(Product product);
	public List<Product> viewitemsp();
	/*public boolean deleteProduct(int pid);
	Product getProductById(int pid);
	void updateProduct(Product product);
	*/
}
