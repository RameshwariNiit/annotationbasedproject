package com.MyShopingB.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.springframework.stereotype.Component;


@Entity
@Table(name="Category")
@Component
public class Category 
{
	@Id
	@Column(name = "cid")
	private int cid;
	
	private String cname;
	private String cdesc;
	//private Set<Product> products;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCdesc() {
		return cdesc;
	}
	public void setCdesc(String cdesc) {
		this.cdesc = cdesc;
	}
	
	/*@OneToMany(mappedBy="category",fetch = FetchType.EAGER)
	public Set<Product> getProducts() 
	{
		return products;
	}
	public void setProducts(Set<Product> products) {
		this.products = products;
	}*/
	
	

}
