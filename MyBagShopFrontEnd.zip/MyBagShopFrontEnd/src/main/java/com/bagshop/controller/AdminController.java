package com.bagshop.controller;

import java.io.IOException;
import java.util.List;


import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


import org.springframework.web.servlet.ModelAndView;

import com.MyShopingB.dao.SupplierDao;
import com.MyShopingB.dao.UserDao;
import com.MyShopingB.model.Supplier;
import com.MyShopingB.model.User;


@Controller
public class AdminController 
{
@Autowired
UserDao userdao;
@Autowired
SupplierDao supplierdao;


@RequestMapping("/viewcust")
public ModelAndView viewCustomers() throws JsonGenerationException, JsonMappingException, IOException
{
	List<User> list = userdao.viewcustomerd();
	System.out.println("user list="+list);
	ObjectMapper om = new ObjectMapper();
	String listjson = om.writeValueAsString(list);
	System.out.println(listjson);
	return new ModelAndView("SeeCustomerData","listofcust",listjson);
}


@RequestMapping("/viewsupp")
public ModelAndView viewSuppliers() throws JsonGenerationException, JsonMappingException, IOException
{
	List<Supplier> slist = supplierdao.viewsupplierd();

	System.out.println(" i am in supplier list="+slist);
	ObjectMapper om = new ObjectMapper();
	String listjson = om.writeValueAsString(slist);
	System.out.println(listjson);
	return new ModelAndView("Supplierinfo","listofsupply",listjson);
	
}

}
