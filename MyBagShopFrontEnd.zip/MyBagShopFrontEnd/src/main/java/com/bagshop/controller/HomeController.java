package com.bagshop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.MyShopingB.dao.UserDao;
import com.MyShopingB.model.User;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;


//@ComponentScan("com.MyShopingB.config")
@Controller
public class HomeController 
{
	@Autowired
	UserDao userdao;
	@RequestMapping("/")
	public ModelAndView Landing()
	{
		ModelAndView land = new ModelAndView("LandingPage");
		
		return land;
	}
	
	@RequestMapping("/Reg")
	public ModelAndView RegPage()
	{
		ModelAndView reg = new ModelAndView("Signup");
		
		return reg;
	}
	
	@RequestMapping("/register")
	public ModelAndView UserPage(@Valid@ModelAttribute("userm") User user , BindingResult br , HttpServletRequest request, Model model)
	{
		System.out.println("I am in Controller");
		
		if(br.hasErrors())
		{
			return new ModelAndView("Signup");
		}
		
		userdao.saveorupdate(user);
		return new ModelAndView("Signup");
		
	}
	@ModelAttribute("userm")
	public  User returnObject()
	{
		return new User();
	}
	
	@RequestMapping("/AdminSecure")
	public ModelAndView AdminCheckp()
	{
		//System.out.println("UserName:"+p.getName());
		
		return new ModelAndView("AdminHome");
	}
	
	
}
