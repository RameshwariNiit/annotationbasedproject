package com.MyShopingB.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.MyShopingB.config.ApplicationContextConfig;
import com.MyShopingB.dao.ProductDao;
import com.MyShopingB.dao.SupplierDao;
import com.MyShopingB.dao.UserDao;
import com.MyShopingB.model.*;
public class TestCases 
{
	static AnnotationConfigApplicationContext context;
	
	
	public TestCases()
	{
	context = new AnnotationConfigApplicationContext(ApplicationContextConfig.class);
	 context.scan("com.MyShopingB");
	//context.refresh();
	}

	
	public static void main(String[] ar)
	{
		try{
		System.out.println("main() started...");
		
		TestCases tc = new TestCases();

		//this is user domain object
		User us = (User) context.getBean("user");
		System.out.println("user -==="+us);
		us.setFname("subbu");
		us.setUsername("subraminyam");
		us.setPassword("sub@123");
		us.setEmailid("sub@yahoo.com");
		us.setMobileno("9889");
		
		System.out.println("user data....."+us);
		//this is dao user object
		UserDao userdao = (UserDao)context.getBean("userdaoimpl");
		System.out.println("user dao="+userdao);
		userdao.saveorupdate(us);
		
		//this is Supplier class
		
		System.out.println("this is supplier information...........");
		Supplier suppl = (Supplier)context.getBean("supplier");
		suppl.setName("GANESH JII");
		suppl.setAddress("IN HEAVEN");
		
		System.out.println("supplier data...."+suppl);

		SupplierDao supplierdao =(SupplierDao) context.getBean("supplierdaoimpl");
		System.out.println("supplier dao ==="+supplierdao);
		supplierdao.saveorupdate(suppl);
		
		
		//this is product class information
		/*Product prod = (Product) context.getBean("product");
		prod.setPname("cotton");
		prod.setPdesc("cotton bags are good");
		prod.setPrice(234.50);
		
		
		System.out.println("product data ..."+prod);
		ProductDao productdao =(ProductDao) context.getBean("productdaoimpl");
		productdao.saveorupdate(prod);
			*/
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("main() ended...");
	}
	
	
	
}
