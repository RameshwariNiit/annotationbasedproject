package com.MyShopingB.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.MyShopingB.model.Product;

@Repository("productdaoimpl")
public class ProductDaoImpl implements ProductDao
{

	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveorupdate(Product product) 
	{
		System.out.println("i am in productdao class");
		Session s = sessionFactory.openSession();
		System.out.println("sesssion="+s);
		s.saveOrUpdate(product);
		System.out.println("product data successfully done");
	}

	public List<Product> viewitemsp() {
		Session s = sessionFactory.openSession();
		@SuppressWarnings("unchecked")
		List<Product> productlist = s.createCriteria(Product.class).list();
		return productlist;
	}

/*	public boolean deleteProduct(int pid) {
	System.out.println("i m in delete product using pid :"+pid);
	Session s = sessionFactory.openSession();
	//Transaction tx = s.beginTransaction();
	Query query =s.createQuery("delete from product where pid=:status");
	query.setInteger("status", pid);
	int rowsdeleted = query.executeUpdate();
	//tx.commit();
	System.out.println("succss fully deleted"+rowsdeleted);
	if(rowsdeleted!=1)
	return true;
	else
		return false;
	}

	public Product getProductById(int pid) {
	Session s = sessionFactory.openSession();
		//Transaction tx = s.beginTransaction();
		Product product = s.load(Product.class,new Integer(pid));
		
		return product;
	}

	public void updateProduct(Product product) {
		Session s = sessionFactory.openSession();
		//Transaction tx = s.beginTransaction();
		s.update(product);
		//tx.commit();
		System.out.println("updated..");
		
	}*/

}
